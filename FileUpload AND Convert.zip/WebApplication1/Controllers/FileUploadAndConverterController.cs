﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;

namespace WebApplication1.Controllers
{
    public class FileUploadAndConverterController : Controller
    {
        // GET: FileUploadAndConverter
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult UploadFile()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UploadFile(HttpPostedFileBase file, string command)
        {
            try
            {
                if (command == "UploadFile")
                {
                    if (file.ContentLength > 0)
                    {
                        var fileSize = 100;
                        var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1);
                        if (fileExt == "xml")
                        {
                            if (file.ContentLength > fileSize * 1024)
                            {
                                ViewBag.Message = "Please select file is less then 1gb!!";
                            }
                            else
                            {
                                string _FileName = Path.GetFileName(file.FileName);
                                string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), _FileName);
                                file.SaveAs(_path);
                                ViewBag.Message = "File Uploaded Successfully!!";
                            }
                        }
                        else
                        {
                            ViewBag.Message = "Please select xml file only!!";
                        }
                    }
                }
                else if (command == "Convert")
                {
                    string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), "ABCD.xml");
                    string xmlString = XDocument.Load(_path).ToString();
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(xmlString);
                    var json = Newtonsoft.Json.JsonConvert.SerializeObject(xml);
                    return View();
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "File upload failed!!" + ex.ToString();
                return View();
            }
            return View();
        }
        public static XmlNodeList GetNode(XmlDocument doc, string nodeName)
        {
            XmlNodeList nodes = doc.GetElementsByTagName(nodeName);
            return nodes;
        }
    }
}